using LinearAlgebra, SparseArrays
using Plots

mkpath("$(@__DIR__)/plots")